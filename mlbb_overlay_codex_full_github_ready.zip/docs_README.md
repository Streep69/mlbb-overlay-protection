# /docs/ README

This folder contains:
- All exported chat logs, anti-ban guides, onboarding, architecture docs, vector manifests, and test logs.
- Always chunk and rotate docs after major updates.
- Update this README with any new document types or file structure changes.
