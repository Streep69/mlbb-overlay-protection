# Changelog
## Community Integrations (2025-06-18)
- Version bump
