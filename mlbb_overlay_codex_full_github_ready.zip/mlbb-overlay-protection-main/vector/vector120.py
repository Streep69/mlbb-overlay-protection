"""Vector module 120
"""
def run() -> str:
    """Run vector 120"""
    return 'vector120 executed'
