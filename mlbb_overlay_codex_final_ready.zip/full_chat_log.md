Initial discussion about anti-cheat vector generation and security workflow.
Updated vector149 and vector150 with functional implementations. Added sandbox assets and extended tests.
Added GH_PAT-based workflows and documented usage.
