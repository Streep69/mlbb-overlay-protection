# Issue/Bug Report

- **Vector/Script:** 
- **Describe the problem:** 
- **Steps to reproduce:** 
- **Logs/Outputs:** 
- **Anti-detection risk:** 
