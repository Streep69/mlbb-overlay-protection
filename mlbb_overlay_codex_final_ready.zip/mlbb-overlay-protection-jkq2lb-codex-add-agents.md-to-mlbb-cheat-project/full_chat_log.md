Initial discussion about anti-cheat vector generation and security workflow.
Updated vector149 and vector150 with functional implementations. Added sandbox assets and extended tests.
Fixed vector149 to handle missing aiohttp and tkinter dependencies.
CI workflow updated to use GH_PAT and sanitize before tests.
Added conflict resolution step and updated CI documentation.
Added auto_rebase workflow with '/rebase' comment and automerge label.
Added auto-rebase script and workflow to handle unrelated histories with -X theirs.
Updated requirements and CI to install system packages, added auto_rebase_allow.sh instructions.
Added unicode sanity checks workflow and enforced ASCII scripts.
Added GitHub CLI authentication script with PAT setup instructions.
Added AGENTS.md with Codex guidance and security workflow.
Added codex_cli_setup.sh for PAT authentication and git setup.
Added GH_PAT-based workflows and documented usage.
Workflows now set git identity to github-actions[bot] before running tests.
Added auto_sync script and CI workflow to keep branches in sync using GH_PAT.
Added Termux setup script for Android environments.
