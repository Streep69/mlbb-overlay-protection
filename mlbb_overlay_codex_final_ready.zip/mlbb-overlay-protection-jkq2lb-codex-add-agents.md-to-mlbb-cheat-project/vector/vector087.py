"""Vector module 087
"""
def run() -> str:
    """Run vector 087"""
    return 'vector087 executed'
