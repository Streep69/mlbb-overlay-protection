import time

def run():
    print("[OverlaySpoofer] Faking overlay window to avoid detection...")
    time.sleep(1)
    print("[OverlaySpoofer] Overlay successfully spoofed.")

if __name__ == "__main__":
    run()