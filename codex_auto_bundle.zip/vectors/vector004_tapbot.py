import random, time

def run():
    print("[Tapbot] Humanized tap injected.")
    time.sleep(random.uniform(0.1, 0.3))
    print("[Tapbot] Tap entropy: OK.")

if __name__ == "__main__":
    run()