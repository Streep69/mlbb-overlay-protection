import os, time

def run():
    print("[Injector] Loading cheat module...")
    time.sleep(1)
    print("[Injector] Module injected and running.")

if __name__ == "__main__":
    run()