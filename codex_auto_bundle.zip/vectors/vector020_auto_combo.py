import time, random

def run():
    print("[AutoCombo] Triggering skill combo...")
    time.sleep(random.uniform(0.2, 0.5))
    print("[AutoCombo] Combo complete.")

if __name__ == "__main__":
    run()