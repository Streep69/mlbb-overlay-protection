import time

def run():
    print("[ScreenshotBlocker] Monitoring screenshot events...")
    time.sleep(1)
    print("[ScreenshotBlocker] Screenshot intercepted, overlay hidden.")

if __name__ == "__main__":
    run()