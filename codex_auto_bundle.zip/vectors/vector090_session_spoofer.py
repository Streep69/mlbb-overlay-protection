import time, random

def run():
    print("[SessionSpoofer] Spoofing session/UUID...")
    time.sleep(random.uniform(0.5, 1.0))
    print("[SessionSpoofer] Session spoofed.")

if __name__ == "__main__":
    run()