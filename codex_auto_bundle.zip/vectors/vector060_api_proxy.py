import time

def run():
    print("[APIProxy] Routing API traffic through proxy...")
    time.sleep(1)
    print("[APIProxy] API proxy active.")

if __name__ == "__main__":
    run()