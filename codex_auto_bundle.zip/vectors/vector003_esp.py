import time

def run():
    print("[ESP] Injecting entity positions...")
    time.sleep(1)
    print("[ESP] Entity overlay OK.")

if __name__ == "__main__":
    run()