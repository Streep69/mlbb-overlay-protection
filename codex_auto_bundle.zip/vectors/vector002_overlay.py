import time

def run():
    print("[Overlay] Floating overlay active. Rendering ESP...")
    time.sleep(1)
    print("[Overlay] Overlay draw cycle complete.")

if __name__ == "__main__":
    run()