import time

def run():
    print("[LogCleaner] Cleaning session logs...")
    time.sleep(1)
    print("[LogCleaner] Logs wiped.")

if __name__ == "__main__":
    run()