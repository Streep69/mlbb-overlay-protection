# Contributing Guide

- Fork repo, add new vector in /vectors/ using template.
- Document each new script/module with README and docstring.
- Log test session in /test/ and update manifest.
- Open pull request and tag related issue if bug or feature.
