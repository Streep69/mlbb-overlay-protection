# AI Model Card Template

- **Model Name:** 
- **Version:** 
- **Input:** (feature set, sensors, log format)
- **Output:** (signal, overlay/tap, decision)
- **Training Data:** (date, source, size)
- **Validation:** (accuracy, last test, known issues)
- **Contact:** 
